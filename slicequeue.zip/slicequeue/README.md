## Slice 'n' Dice

Slices archive newspaper images into the article sections described in the XML.

## Usage

To run:

```
./index.js # assumes node is installed to /usr/local/bin
```

## TODO

* Fix the race conditions with image processing.
* Do the cleanup.
* Make it accept more command line arguments.
